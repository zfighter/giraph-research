package cn.ac.ict.util;

public class MutableInteger extends MutationBase<Integer> {

	public MutableInteger(int value){
		super(value);
	}

}
