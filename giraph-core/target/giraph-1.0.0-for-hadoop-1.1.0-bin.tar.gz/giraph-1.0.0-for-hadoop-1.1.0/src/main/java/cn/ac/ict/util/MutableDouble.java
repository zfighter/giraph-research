package cn.ac.ict.util;

public class MutableDouble extends MutationBase<Double> {
	
	public MutableDouble(){
		super(0.0);
	}
	
	public MutableDouble(double value){
		super(value);
	}

}
